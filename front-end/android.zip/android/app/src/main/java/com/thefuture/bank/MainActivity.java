package com.thefuture.bank;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
